package com.axelzerox23.sprunki;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private static final int DATA_VERSION = 2;          // غيّره لو حدّثت اللعبة => يعيد الفك
    private static final String URL = "https://appassets.androidplatform.net/assets/www/index.html";

    private WebView web;
    private TextView status;
    private FrameLayout root;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private File gameDir;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setText("…");
        root.addView(status, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        goImmersive();

        gameDir = new File(getFilesDir(), "game");
        if (isReady()) { startWeb(); return; }

        status.setText("أول تشغيل: جاري تجهيز اللعبة…\nFirst launch: preparing game…");
        new Thread(() -> {
            try {
                unpack();
                ui.post(this::startWeb);
            } catch (Throwable t) {
                ui.post(() -> status.setText("Error: " + t + "\n(تأكد من وجود مساحة فاضية ~60MB)"));
            }
        }).start();
    }

    private boolean isReady() {
        File ok = new File(gameDir, ".ok");
        if (!ok.exists()) return false;
        try (FileInputStream in = new FileInputStream(ok)) {
            byte[] buf = new byte[16];
            int n = in.read(buf);
            return n > 0 && Integer.parseInt(new String(buf, 0, n).trim()) == DATA_VERSION;
        } catch (Exception e) { return false; }
    }

    private static void deleteRec(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        f.delete();
    }

    /** يفك game.sb3 إلى /data/data/<pkg>/files/game/{project.json, assets/*} */
    private void unpack() throws IOException {
        File tmp = new File(getFilesDir(), "game.tmp");
        deleteRec(tmp); deleteRec(gameDir);
        File assets = new File(tmp, "assets");
        if (!assets.mkdirs()) throw new IOException("mkdir failed");

        AssetFileDescriptor afd = getAssets().openFd("www/game.sb3");
        final long total = Math.max(1, afd.getLength());
        final long[] read = {0};
        InputStream raw = new FilterInputStream(afd.createInputStream()) {
            @Override public int read() throws IOException { int r = super.read(); if (r >= 0) read[0]++; return r; }
            @Override public int read(byte[] b, int o, int l) throws IOException { int r = super.read(b, o, l); if (r > 0) read[0] += r; return r; }
        };
        long lastUi = 0;
        byte[] buf = new byte[64 * 1024];
        try (ZipInputStream zin = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName();
                if (e.isDirectory() || name.contains("/") || name.contains("\\") || name.contains("..")) continue;
                File out = name.equals("project.json") ? new File(tmp, name) : new File(assets, name);
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                long now = System.currentTimeMillis();
                if (now - lastUi > 150) {
                    lastUi = now;
                    final int pct = (int) Math.min(99, read[0] * 100 / total);
                    ui.post(() -> status.setText("أول تشغيل: جاري تجهيز اللعبة… " + pct + "%\nFirst launch: preparing… " + pct + "%"));
                }
            }
        }
        afd.close();
        try (FileOutputStream os = new FileOutputStream(new File(tmp, ".ok"))) {
            os.write(String.valueOf(DATA_VERSION).getBytes());
        }
        if (!tmp.renameTo(gameDir)) throw new IOException("rename failed");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void startWeb() {
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/data/", new WebViewAssetLoader.InternalStoragePathHandler(this, gameDir))
                .build();

        web = new WebView(this);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setBackgroundColor(Color.BLACK);
        root.addView(web, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        status.setVisibility(View.GONE);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBlockNetworkLoads(true);
        s.setAllowFileAccess(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            // لو النظام قتل عملية الـ WebView بسبب نقص الرام: لا ينهار التطبيق، يعيد التشغيل
            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                ui.post(() -> recreate());
                return true;
            }
        });
        web.loadUrl(URL);
    }

    private void goImmersive() {
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) goImmersive(); }
    @Override protected void onPause() { super.onPause(); if (web != null) web.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }

    @Override
    public void onBackPressed() {
        if (web == null) { finish(); return; }
        web.evaluateJavascript("(window.__closeDesc&&window.__closeDesc())||false", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    @Override protected void onDestroy() {
        if (web != null) { root.removeView(web); web.destroy(); }
        super.onDestroy();
    }
}
